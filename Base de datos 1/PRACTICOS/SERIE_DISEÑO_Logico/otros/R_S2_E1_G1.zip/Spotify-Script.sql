
USE Spotify

CREATE TABLE Gender
(
  id_gender INT NOT NULL,
  nombre VARCHAR NOT NULL,
  CONSTRAINT id_gender PRIMARY KEY (id_gender),
);

CREATE TABLE UserApp
(
  name VARCHAR(255) NOT NULL,
  id_user INT NOT NULL,
  correo VARCHAR(100) NOT NULL,
  fechaRegistro DATE NOT NULL,
  CONSTRAINT id_user PRIMARY KEY (id_user),
);

CREATE TABLE Playlist
(
  id_playlist INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  fechaCreacion DATE NOT NULL,
  CONSTRAINT id_playlist PRIMARY KEY (id_playlist)
);

CREATE TABLE Album
(
  id_album INT NOT NULL,
  titulo VARCHAR(100) NOT NULL,
  CONSTRAINT id_album PRIMARY KEY (id_album),
);

CREATE TABLE Artist
(
  id_artista INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  CONSTRAINT id_artista PRIMARY KEY (id_artista),
);

CREATE TABLE User_Playlist
(
  id_userPlaylist INT NOT NULL,
  id_user INT NOT NULL,
  CONSTRAINT id_userPlaylist PRIMARY KEY (id_userPlaylist),
  CONSTRAINT FK_idPlaylist1 FOREIGN KEY (id_userPlaylist) REFERENCES Playlist (id_playlist),
  CONSTRAINT FK_idUser FOREIGN KEY (id_user) REFERENCES UserApp (id_user)
);

CREATE TABLE Media_Type
(
  id_media_type INT NOT NULL,
  description VARCHAR(255) NOT NULL,
  CONSTRAINT id_media_type PRIMARY KEY (id_media_type)
);

CREATE TABLE Media
(
  id_media INT NOT NULL,
  titulo VARCHAR(100) NOT NULL,
  duracion DATE NOT NULL,
  a�oLanzamiento INT NOT NULL,
  id_album INT NOT NULL,
  id_media_type INT NOT NULL,
  CONSTRAINT id_media PRIMARY KEY (id_media),
  CONSTRAINT FK_idAlbum FOREIGN KEY (id_album) REFERENCES Album (id_album),
  CONSTRAINT FK_idMedia_type FOREIGN KEY (id_media_type) REFERENCES Media_Type (id_media_type),
);

CREATE TABLE Artist_Media
(
  id_media INT NOT NULL,
  id_artista INT NOT NULL,
  CONSTRAINT id_media_artista PRIMARY KEY (id_media, id_artista),
  CONSTRAINT FK_idMedia FOREIGN KEY (id_media) REFERENCES Media (id_media),
  CONSTRAINT FK_idArtista FOREIGN KEY (id_artista) REFERENCES Artist (id_artista),
);

CREATE TABLE Media_gender
(
  id_media INT NOT NULL,
  id_gender INT NOT NULL,
  CONSTRAINT id_media_gender PRIMARY KEY (id_media, id_gender),
  CONSTRAINT FK_idMedia1 FOREIGN KEY (id_media) REFERENCES Media (id_media),
  CONSTRAINT FK_idGender FOREIGN KEY (id_gender) REFERENCES Gender (id_gender),
);

CREATE TABLE Media_Playlist
(
  id_media INT NOT NULL,
  id_playlist INT NOT NULL,
  CONSTRAINT id_media_playlist PRIMARY KEY (id_media, id_playlist),
  CONSTRAINT FK_idMedia2 FOREIGN KEY (id_media) REFERENCES Media (id_media),
  CONSTRAINT FK_idPlaylist2 FOREIGN KEY (id_playlist) REFERENCES Playlist (id_playlist),
);