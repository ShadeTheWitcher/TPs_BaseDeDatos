CREATE DATABASE barquito_db;

USE barquito_db;

CREATE TABLE Usuario
(
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  dni_creador INT NOT NULL,
  PRIMARY KEY (dni_creador)
);

CREATE TABLE Licencia_Conductor
(
  nro_licencia INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  createdAt DATE NOT NULL,
  dni_creador INT NOT NULL,
  PRIMARY KEY (nro_licencia),
  FOREIGN KEY (dni_creador) REFERENCES Usuario(dni_creador)
);

CREATE TABLE Pasajero
(
  dni_pasajero INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  apelido VARCHAR(100) NOT NULL,
  direccion VARCHAR(100) NOT NULL,
  createdAt DATE NOT NULL,
  dni_creador INT NOT NULL,
  PRIMARY KEY (dni_pasajero),
  FOREIGN KEY (dni_creador) REFERENCES Usuario(dni_creador)
);

CREATE TABLE Categoria
(
  id_categoria INT NOT NULL,
  tipo_categoria VARCHAR(100) NOT NULL,
  createdAt DATE NOT NULL,
  dni_creador INT NOT NULL,
  PRIMARY KEY (id_categoria),
  FOREIGN KEY (dni_creador) REFERENCES Usuario(dni_creador)
);

CREATE TABLE Salida
(
  num_registro INT NOT NULL,
  fecha_salida DATE NOT NULL,
  hora_salida DATE NOT NULL,
  destino VARCHAR(100) NOT NULL,
  createdAt DATE NOT NULL,
  nro_licencia INT NOT NULL,
  dni_creador INT NOT NULL,
  PRIMARY KEY (num_registro),
  FOREIGN KEY (nro_licencia) REFERENCES Licencia_Conductor(nro_licencia),
  FOREIGN KEY (dni_creador) REFERENCES Usuario(dni_creador)
);

CREATE TABLE Socio
(
  nro_socio INT NOT NULL,
  fecha_alta DATE NOT NULL,
  createdAt DATE NOT NULL,
  correoElectronico VARCHAR(150) NOT NULL,
  id_categoria INT NOT NULL,
  dni_creador INT NOT NULL,
  PRIMARY KEY (nro_socio),
  FOREIGN KEY (id_categoria) REFERENCES Categoria(id_categoria),
  FOREIGN KEY (dni_creador) REFERENCES Usuario(dni_creador),
  UNIQUE (correoElectronico)
);

CREATE TABLE Boleto
(
  createdAt DATE NOT NULL,
  num_registro INT NOT NULL,
  dni_pasajero INT NOT NULL,
  dni_creador INT NOT NULL,
  PRIMARY KEY (num_registro, dni_pasajero),
  FOREIGN KEY (num_registro) REFERENCES Salida(num_registro),
  FOREIGN KEY (dni_pasajero) REFERENCES Pasajero(dni_pasajero),
  FOREIGN KEY (dni_creador) REFERENCES Usuario(dni_creador)
);

CREATE TABLE Embarcacion
(
  num_matricula INT NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  num_amarre INT NOT NULL,
  createdAt DATE NOT NULL,
  nro_socio INT NOT NULL,
  num_registro INT NOT NULL,
  dni_creador INT NOT NULL,
  PRIMARY KEY (num_matricula),
  FOREIGN KEY (nro_socio) REFERENCES Socio(nro_socio),
  FOREIGN KEY (num_registro) REFERENCES Salida(num_registro),
  FOREIGN KEY (dni_creador) REFERENCES Usuario(dni_creador)
);